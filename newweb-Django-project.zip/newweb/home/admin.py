from django.contrib import admin
from home.models import product

# Register your models here.
admin.site.register(product)