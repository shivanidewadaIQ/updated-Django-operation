from django.http import HttpResponse
from django.shortcuts import render


def homepage(request):
    data={
        'title':'home page',
        'maindata':'content of page',
        'clist':['maths','science','django'],
        'student details':[
            {'name':'karan','phone':'9867965596'},
            {'name':'parag','phone':'8989667895'}
        ]
    }
    return render(request,"index.html",data)

def aboutUs(request):
    return HttpResponse("<b>welcome to the newweb page<b/>")
def course(request):
    return HttpResponse("welcome to the course page")